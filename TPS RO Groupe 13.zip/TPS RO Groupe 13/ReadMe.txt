Nom Groupe : Groupe 13

Nom Membre et pourcentages finaux: 
		Foupouagnigni Mowoum (chef) 30%
		Mbang Belvine 25%
		Yimdjo	25%
		Aboubacar 20%

Methodologie et structuration du Dossier : 

		Chaque TP a été attriber à des sous equipes . 
		Pour chaque TP , un Cahier de charge est present , le rapport , et le code integrale , ainsi que les read me. 
			
	
Repartition des TP et implication des membres 

	
	TP1 : Algorithme de Dijstkra , Prime , Kruskal
		Foupouagnigni Mowoum (chef) (chef sous equipe) 60%
		Mbang Belvine 20%
		Yimdjo	20%
		Aboubacar 0% 
	TP2 : Algorithme de Pert ( avec interface Graphique)
		Foupouagnigni Mowoum (chef) ( chef sous equipe) 60%
		Mbang Belvine 40%
		Yimdjo	0%
		Aboubacar 0% 
	TP3 : Algorithme de Simplexe
		Foupouagnigni Mowoum (chef) 0%
		Mbang Belvine 0%
		Yimdjo ( sous equipe)	60%
		Aboubacar 40% 





Compétences acquise : 
		
	+Programmation Java Niveau amateur.
	+Integration de solution tierces comme GraphViz.
	+Adaptation , réutilisation et  modularité de code.
	+Elevation de l'abstraction Logiciel. 
	 