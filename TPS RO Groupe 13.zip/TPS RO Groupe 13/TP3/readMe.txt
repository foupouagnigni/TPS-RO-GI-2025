/*********************************** 4GI ENSPY 2025**********************************************************/
/*********************************** Nom Projet : TP3 RO Algorithme de Simplexe*********************************/
				
               Ce Projet Implémente l'algorithme de simplexe . Avec une approche orienté objet absolue. 





/******************************** Auteur du code  : yimdjo(backend) , aboubacar Datty ( interface front end)************/



/****************************Utilisation********************************************************************/

il vous suffit dès lors à lancer la classe simplexe( main classe) et de suivre les instructions pour pouvoir utiliser notre algorithme . 

Dans la console ,vous verrez le resultat.
