package Simplexe;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class simplexe {

    // Classe interne pour représenter le tableau simplex
    public static class Tableau {
        public List<List<Double>> entries = new ArrayList<>();
        public List<String> rowLabels = new ArrayList<>();
        public List<String> columnLabels = new ArrayList<>();

        public Tableau(int numRows, int numColumns) {
            // Initialiser le tableau avec des listes vides
            for (int i = 0; i < numRows; i++) {
                rowLabels.add("");
                entries.add(new ArrayList<>());
                for (int j = 0; j < numColumns; j++) {
                    entries.get(i).add(0.0);
                }
            }
            // Initialiser les étiquettes de colonne avec des chaînes vides
            for (int j = 0; j < numColumns; j++) {
                columnLabels.add("");
            }
        }

        public void setEntry(int row, int column, double value) {
            // Définir la valeur d'une entrée du tableau
            entries.get(row).set(column, value);
        }

        public double getEntry(int row, int column) {
            // Récupérer la valeur d'une entrée du tableau
            return entries.get(row).get(column);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Demander à l'utilisateur d'entrer les données du problème d'optimisation linéaire
        System.out.print("Entrez le nombre de variables décisionnelles : ");
        int numVariables = scanner.nextInt();

        System.out.print("Entrez le nombre de contraintes : ");
        int numConstraints = scanner.nextInt();

        // Initialiser le tableau
        Tableau tableau = new Tableau(numConstraints + 1, numVariables + numConstraints + 1);
        for (int i = 0; i < numConstraints; i++) {
            tableau.rowLabels.set(i, "c" + (i + 1));
        }
        tableau.rowLabels.add("");
        for (int j = 0; j < numVariables; j++) {
            tableau.columnLabels.set(j, "x" + (j + 1));
        }
        for (int j = numVariables; j < numVariables + numConstraints; j++) {
            tableau.columnLabels.set(j, "s" + (j - numVariables + 1));
        }
        tableau.columnLabels.set(numVariables + numConstraints, "RHS");

        // Demander à l'utilisateur d'entrer la fonction objectif
        System.out.println("Entrez les coefficients de la fonction objectif (séparés par des espaces) :");
        for (int j = 0; j < numVariables; j++) {
            tableau.setEntry(numConstraints, j, -scanner.nextDouble());
        }

        // Demander à l'utilisateur d'entrer les contraintes
        for (int i = 0; i < numConstraints; i++) {
            System.out.println("Entrez les coefficients de la contrainte " + (i + 1) + " (séparés par des espaces) :");
            for (int j = 0; j < numVariables; j++) {
                tableau.setEntry(i, j, scanner.nextDouble());
            }
            System.out.print("Entrez le terme constant de la contrainte " + (i + 1) + " : ");
            tableau.setEntry(i, numVariables + numConstraints, scanner.nextDouble());
            tableau.setEntry(i, numVariables + i, 1.0);
        }

        // Appliquer l'algorithme du simplex
        int iterations = 0;
        while (!isOptimal(tableau) && iterations < 100) {
            iterations++;
            Tableau newTableau = pivot(tableau);
            if (newTableau == null) {
                System.out.println("Pas de solution");
                return;
            }
            tableau = newTableau;
            printTableau(tableau);
        }

        if (iterations == 100) {
            System.out.println("L'algorithme n'a pas convergé");
            return;
        }

        // Afficher la solution
        System.out.print("Solution optimale : ");
        for (int j = 0; j < numVariables; j++) {
            System.out.printf("x%d = %.2f, ", j + 1, tableau.getEntry(numConstraints, j));
        }
        System.out.printf("z = %.2f", -tableau.getEntry(numConstraints, numVariables + numConstraints));
        System.out.println();
    }

    //La mise en forme du code a été tronquée accidentellement dans ma réponse précédente. Voici la suite du code pour compléter l'implémentation de l'algorithme du simplexe :

    // Vérifie si le tableau est optimal
    public static boolean isOptimal(Tableau tableau) {
        int numVariables = tableau.columnLabels.size() - 1;
        for (int j = 0; j < numVariables; j++) {
            if (tableau.getEntry(tableau.entries.size() - 1, j) < 0) {
                return false;
            }
        }
        return true;
    }

    // Effectue une opération de pivot sur le tableau
    public static Tableau pivot(Tableau tableau) {
        int pivotColumn = findPivotColumn(tableau);
        if (pivotColumn == -1) {
            return null;
        }

        int pivotRow = findPivotRow(tableau, pivotColumn);
        if (pivotRow == -1) {
            return null;
        }

        Tableau newTableau = new Tableau(tableau.entries.size(), tableau.entries.get(0).size());

        // Mettre à jour les étiquettes de ligne
        for (int i = 0; i < tableau.rowLabels.size(); i++) {
            newTableau.rowLabels.set(i, tableau.rowLabels.get(i));
        }

        // Mettre à jour les étiquettes de colonne
        for (int j = 0; j < tableau.columnLabels.size(); j++) {
            newTableau.columnLabels.set(j, tableau.columnLabels.get(j));
        }

        // Mettre à jour les entrées du tableau
        double pivotValue = tableau.getEntry(pivotRow, pivotColumn);
        for (int i = 0; i < tableau.entries.size(); i++) {
            for (int j = 0; j < tableau.entries.get(i).size(); j++) {
                if (i == pivotRow && j == pivotColumn) {
                    newTableau.setEntry(i, j, 1 / pivotValue);
                } else if (i == pivotRow) {
                    newTableau.setEntry(i, j, tableau.getEntry(i, j) / pivotValue);
                } else if (j == pivotColumn) {
                    newTableau.setEntry(i, j, -tableau.getEntry(i, j) / pivotValue);
                } else {
                    double entry = tableau.getEntry(i, j);
                    double pivotRowValue = tableau.getEntry(pivotRow, j);
                    double pivotColumnValue = tableau.getEntry(i, pivotColumn);
                    double newValue = entry - (pivotRowValue * pivotColumnValue) / pivotValue;
                    newTableau.setEntry(i, j, newValue);
                }
            }
        }

        return newTableau;
    }

    // Trouve la colonne pivot
    public static int findPivotColumn(Tableau tableau) {
        int numVariables = tableau.columnLabels.size() - 1;
        int pivotColumn = -1;
        double mostNegativeValue = 0.0;
        for (int j = 0; j < numVariables; j++) {
            double value = tableau.getEntry(tableau.entries.size() - 1, j);
            if (value < mostNegativeValue) {
                mostNegativeValue = value;
                pivotColumn = j;
            }
        }
        return pivotColumn;
    }

    // Trouve la ligne pivot
    public static int findPivotRow(Tableau tableau, int pivotColumn) {
        int pivotRow = -1;
        double minRatio = Double.MAX_VALUE;
        for (int i = 0; i < tableau.entries.size() - 1; i++) {
            double rhs = tableau.getEntry(i, tableau.entries.get(i).size() - 1);
            double columnValue = tableau.getEntry(i, pivotColumn);
            if (columnValue > 0) {
                double ratio = rhs / columnValue;
                if (ratio < minRatio) {
                    minRatio = ratio;
                    pivotRow = i;
                }
            }
        }
        return pivotRow;
    }

    // Affiche le tableau
    public static void printTableau(Tableau tableau) {
        System.out.print("      ");
        for (String columnLabel : tableau.columnLabels) {
            System.out.printf("%8s", columnLabel);
        }
        System.out.println();
        for (int i = 0; i < tableau.entries.size(); i++) {
            System.out.printf("%-6s", tableau.rowLabels.get(i));
            for (double entry : tableau.entries.get(i)) {
                System.out.printf("%8.2f", entry);
            }
            System.out.println();
        }
        System.out.println();
    }
}