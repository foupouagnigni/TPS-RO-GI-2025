Tp1 : implementation algorithme Dijkstra , prime kruskal 

**************etat d'avancement*********************

-matrice d'adjacence 100%

-liste chainée 0%

-génération du graphe et du graph plus court chemin  : 100%
(GenGraph, GenGraphCPC(chemin le plus court))

-codage algorithmes (Dijkstra, prime , Kruskal) : 100%

-interface d'accueil : 100%

-interface dijkstra : 70 % ( manque la liaison de l'interface au backEnd)

-interface prime/Kruskal : 0%

-rapport 0% 



**************prérequis  

avoir installer Graphviz sur sa machine


**************comment ça marche : 

Lancer (run) la classe PlusCourtChemin4 qui se trouve dans src du package plusCourtChemin4

vous verrez en invite de commande le chemin le plus court en fonction de la matrice d'adjacence qui se trouve dans le code de la classe principale (cheminlepluscourt.java ligne 25) si vous changer la matrice , le graphe changera , le plus court chemin aussi . 

le graphe est générer en .png et se trouve dans la racine du projet . 

Le graphe du plus court chemin est également générer

les algorithmes de prim et Kruskal se trouvent dans le dossier belvine . Ils n'ont pas encore été lier dans le projet mais fonctionnent .

**************test : 

nous avons testé notre algorithme avec les graphes du document : graphe pdf page 15 ( pour Dijkstra) 

 

**************pourcentage de participation 

Foupouagnigni Mowoum (chef)     60% 

Yimdjo          20%

Mbang belvine    20%

Aboubacar datty  0%


