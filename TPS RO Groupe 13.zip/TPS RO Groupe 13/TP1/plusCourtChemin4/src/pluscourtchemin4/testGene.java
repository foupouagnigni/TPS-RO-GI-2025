/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pluscourtchemin4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class testGene {
    public static void main(String[] args) {
        
String fileName="GenGraph.dot";
        try {
            // Création du process builder avec la commande et les arguments
            ProcessBuilder processBuilder = new ProcessBuilder("dot", "-T", "png", fileName, "-o", fileName + ".png");
            processBuilder.directory(new File(".")); // Répertoire courant

            // Exécution de la commande
            Process process = processBuilder.start();

            // Attente de la fin de l'exécution de la commande
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                System.out.println("La commande s'est exécutée avec succès.");
            } else {
                System.out.println("La commande a échoué avec le code de sortie : " + exitCode);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}