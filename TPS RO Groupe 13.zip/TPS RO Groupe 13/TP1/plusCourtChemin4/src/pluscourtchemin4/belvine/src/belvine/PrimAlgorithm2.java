import java.util.Arrays;

public class PrimAlgorithm2 {
    private static final int INFINITY = Integer.MAX_VALUE;
    
    public static int[] findShortestPath(int[][] graph) {
        int numVertices = graph.length;
        
        // Tableau pour stocker les clés (valeurs minimales) des sommets
        int[] keys = new int[numVertices];
        Arrays.fill(keys, INFINITY);
        
        // Tableau pour stocker les parents des sommets dans l'arbre de poids minimum
        int[] parents = new int[numVertices];
        
        // Tableau pour suivre les sommets inclus dans l'arbre de poids minimum
        boolean[] inTree = new boolean[numVertices];
        
        // Le premier sommet est choisi arbitrairement comme sommet de départ
        keys[0] = 0;
        parents[0] = -1;
        
        // Recherche du plus court chemin
        for (int i = 0; i < numVertices - 1; i++) {
            int u = findMinKeyVertex(keys, inTree);
            inTree[u] = true;
            
            for (int v = 0; v < numVertices; v++) {
                if (graph[u][v] != 0 && !inTree[v] && graph[u][v] < keys[v]) {
                    keys[v] = graph[u][v];
                    parents[v] = u;
                }
            }
        }
        
        return parents;
    }
    
    private static int findMinKeyVertex(int[] keys, boolean[] inTree) {
        int minKey = INFINITY;
        int minKeyVertex = -1;
        
        for (int v = 0; v < keys.length; v++) {
            if (!inTree[v] && keys[v] < minKey) {
                minKey = keys[v];
                minKeyVertex = v;
            }
        }
        
        return minKeyVertex;
    }
    
    public static void main(String[] args) {
        int[][] graph = {
                            {0,2,0,0,0,0,2},
                            {2,0,0,10,2,0,15},
                            {0,0,0,7,10,12,5},
                            {0,10,7,0,1,0,3},
                            {0,2,10,1,0,11,0},
                            {0,0,12,0,11,0,0},
                            {2,15,5,3,0,0,0},
                            
        };
        
        int[] parents = findShortestPath(graph);
        
        System.out.println("Plus court chemin (par ordre de parcours) :");
        for (int i = 1; i < parents.length; i++) {
            System.out.println(parents[i] + " -> " + i);
        }
    }
}