import java.util.*;

public class KruskalAlgorithm2 {
    private static class Edge {
        int source;
        int destination;
        int weight;
        
        public Edge(int source, int destination, int weight) {
            this.source = source;
            this.destination = destination;
            this.weight = weight;
        }
    }
    
    public static List<Edge> findMinimumSpanningTree(int[][] graph) {
        int numVertices = graph.length; // Nombre de sommets dans le graphe
        List<Edge> minimumSpanningTree = new ArrayList<>(); // Liste pour stocker les arêtes de l'arbre couvrant minimal
        List<Edge> edges = new ArrayList<>(); // Liste pour stocker toutes les arêtes du graphe
        
        // Ajouter toutes les arêtes du graphe à la liste des arêtes
        for (int i = 0; i < numVertices; i++) {
            for (int j = i + 1; j < numVertices; j++) {
                if (graph[i][j] != 0) { // Si une arête existe entre les sommets i et j
                    edges.add(new Edge(i, j, graph[i][j])); // Ajouter l'arête à la liste des arêtes
                }
            }
        }
        
        // Trier les arêtes selon leur poids croissant
        Collections.sort(edges, Comparator.comparingInt(e -> e.weight));
        
        int[] subsets = new int[numVertices]; // Tableau pour représenter les ensembles disjoints
        int[] ranks = new int[numVertices]; // Tableau pour stocker les rangs des ensembles
        
        for (int i = 0; i < numVertices; i++) {
            subsets[i] = i; // Au départ, chaque sommet est dans son propre ensemble
            ranks[i] = 0; // Au départ, le rang de chaque ensemble est 0
        }
        
        int numEdges = 0; // Compteur pour le nombre d'arêtes ajoutées à l'arbre couvrant minimal
        int index = 0; // Index pour parcourir les arêtes dans l'ordre croissant de poids
        
        while (numEdges < numVertices - 1) { // Tant que l'arbre couvrant minimal n'a pas (V-1) arêtes
            Edge edge = edges.get(index++); // Récupérer l'arête suivante de la liste des arêtes
            
            int sourceParent = find(subsets, edge.source); // Trouver le représentant de l'ensemble contenant la source de l'arête
            int destinationParent = find(subsets, edge.destination); // Trouver le représentant de l'ensemble contenant la destination de l'arête
            
            if (sourceParent != destinationParent) { // Si les sommets sont dans des ensembles différents (pas de cycle)
                minimumSpanningTree.add(edge); // Ajouter l'arête à l'arbre couvrant minimal
                union(subsets, ranks, sourceParent, destinationParent); // Fusionner les ensembles
                numEdges++; // Incrémenter le compteur d'arêtes
            }
        }
        
        return minimumSpanningTree; // Retourner l'arbre couvrant minimal
    }
    
    private static int find(int[] subsets, int vertex) {
        if (subsets[vertex] != vertex) { // Si le sommet n'est pas le représentant de son ensemble
            subsets[vertex] = find(subsets, subsets[vertex]); // Récurseivement trouver le représentant et le mettre à jour
        }
        
        return subsets[vertex]; // Retourner le représentant de l'ensemble
    }
    
    private static void union(int[] subsets, int[] ranks, int x, int y) {
        int xRoot = find(subsets, x); // Trouver le représentant de l'ensemble contenant x
        int yRoot = find(subsets, y); // Trouver le représentant de l'ensemble contenant y
        
        if (ranks[xRoot] < ranks[yRoot]) { // Si le rang de x est inférieur au rang de y
            subsets[xRoot] = yRoot; // Faire de y le représentant de l'ensemble contenant x
        } else if (ranks[xRoot] > ranks[yRoot]) { // Si le rang de x est supérieur au rang de y
            subsets[yRoot] = xRoot; // Faire de x le représentant de l'ensemble contenant y
        } else { // Si les rangs de x et y sont égaux
            subsets[yRoot] = xRoot; // Faire de x le représentant de l'ensemble contenant y
            ranks[xRoot]++; // Augmenter le rang de x
        }
    }
    
    public static void main(String[] args) {
        int[][] graph = {
                            {0,2,0,0,0,0,2},
                            {2,0,0,10,2,0,15},
                            {0,0,0,7,10,12,5},
                            {0,10,7,0,1,0,3},
                            {0,2,10,1,0,11,0},
                            {0,0,12,0,11,0,0},
                            {2,15,5,3,0,0,0},
                            
        };
        
        List<Edge> minimumSpanningTree = findMinimumSpanningTree(graph);
        
        System.out.println("Arêtes de l'arbre couvrant minimal :");
        for (Edge edge : minimumSpanningTree) {
            System.out.println(edge.source + " - " + edge.destination + " : " + edge.weight);
        }
    }
}