import java.util.*;

public class PrimAlgorithm {
    private static class Edge {
        int destination;
        int weight;
        
        public Edge(int destination, int weight) {
            this.destination = destination;
            this.weight = weight;
        }
    }
    
    private static class Node {
        int vertex;
        List<Edge> edges;
        
        public Node(int vertex) {
            this.vertex = vertex;
            this.edges = new ArrayList<>();
        }
        
        public void addEdge(int destination, int weight) {
            edges.add(new Edge(destination, weight));
        }
    }
    
    public static int[] findShortestPath(List<Node> graph) {
        int numVertices = graph.size();
        
        int[] keys = new int[numVertices];
        Arrays.fill(keys, Integer.MAX_VALUE);
        
        int[] parents = new int[numVertices];
        
        boolean[] inTree = new boolean[numVertices];
        
        keys[0] = 0; // Clé du premier sommet est mise à 0
        parents[0] = -1; // Le premier sommet n'a pas de parent
        
        for (int i = 0; i < numVertices - 1; i++) {
            int u = findMinKeyVertex(keys, inTree); // Trouver le sommet avec la plus petite clé non inclus dans l'arbre
            inTree[u] = true; // Marquer le sommet comme inclus dans l'arbre
            
            Node node = graph.get(u); // Récupérer le nœud correspondant au sommet courant
            for (Edge edge : node.edges) { // Parcourir les arêtes du nœud
                int v = edge.destination; // Destination de l'arête
                int weight = edge.weight; // Poids de l'arête
                
                if (!inTree[v] && weight < keys[v]) { // Si le sommet n'est pas inclus dans l'arbre et le poids est plus petit que la clé
                    keys[v] = weight; // Mettre à jour la clé du sommet
                    parents[v] = u; // Mettre à jour le parent du sommet
                }
            }
        }
        
        return parents; // Retourner le tableau des parents
    }
    
    private static int findMinKeyVertex(int[] keys, boolean[] inTree) {
        int minKey = Integer.MAX_VALUE;
        int minKeyVertex = -1;
        
        for (int v = 0; v < keys.length; v++) {
            if (!inTree[v] && keys[v] < minKey) { // Si le sommet n'est pas inclus dans l'arbre et la clé est plus petite
                minKey = keys[v]; // Mettre à jour la plus petite clé
                minKeyVertex = v; // Mettre à jour le sommet correspondant
            }
        }
        
        return minKeyVertex; // Retourner le sommet avec la plus petite clé
    }
    
    public static void main(String[] args) {
        List<Node> graph = new ArrayList<>();
        
        for (int i = 0; i < 5; i++) {
            graph.add(new Node(i));
        }
        
        // Ajouter les arêtes pour chaque nœud du graphe
        graph.get(0).addEdge(1, 2);
        graph.get(0).addEdge(3, 6);
        
        graph.get(1).addEdge(0, 2);
        graph.get(1).addEdge(2, 3);
        graph.get(1).addEdge(3, 8);
        graph.get(1).addEdge(4, 5);
        
        graph.get(2).addEdge(1, 3);
        graph.get(2).addEdge(4, 7);
        
        graph.get(3).addEdge(0, 6);
        graph.get(3).addEdge(1, 8);
        graph.get(3).addEdge(4, 9);
        
        graph.get(4).addEdge(1, 5);
        graph.get(4).addEdge(2, 7);
        graph.get(4).addEdge(3, 9);
        
        int[] parents = findShortestPath(graph);
        
        System.out.println("Plus court chemin (par ordre de parcours) :");
        for (int i = 1; i < parents.length; i++) {
            System.out.println(parents[i] + " -> " + i);
        }
    }
}