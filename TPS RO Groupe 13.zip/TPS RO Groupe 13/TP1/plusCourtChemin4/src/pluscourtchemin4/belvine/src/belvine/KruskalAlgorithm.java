import java.util.*;

public class KruskalAlgorithm {
    private static class Edge {
        int source;
        int destination;
        int weight;
        
        public Edge(int source, int destination, int weight) {
            this.source = source;
            this.destination = destination;
            this.weight = weight;
        }
    }
    
    private static class Subset {
        int parent;
        int rank;
        
        public Subset(int parent, int rank) {
            this.parent = parent;
            this.rank = rank;
        }
    }
    
    private static class Node {
        int vertex;
        List<Edge> edges;
        
        public Node(int vertex) {
            this.vertex = vertex;
            this.edges = new ArrayList<>();
        }
        
        public void addEdge(int destination, int weight) {
            edges.add(new Edge(vertex, destination, weight));
        }
    }
    
    public static List<Edge> findMinimumSpanningTree(List<Node> graph) {
        List<Edge> minimumSpanningTree = new ArrayList<>();
        List<Edge> edges = new ArrayList<>();
        
        // Ajouter toutes les arêtes du graphe à la liste des arêtes
        for (Node node : graph) {
            edges.addAll(node.edges);
        }
        
        // Trier les arêtes selon leur poids croissant
        Collections.sort(edges, Comparator.comparingInt(e -> e.weight));
        
        Subset[] subsets = new Subset[graph.size()];
        for (int i = 0; i < subsets.length; i++) {
            subsets[i] = new Subset(i, 0);
        }
        
        int numEdges = 0;
        int index = 0;
        
        while (numEdges < graph.size() - 1) {
            Edge edge = edges.get(index++);
            
            int sourceParent = find(subsets, edge.source);
            int destinationParent = find(subsets, edge.destination);
            
            if (sourceParent != destinationParent) {
                minimumSpanningTree.add(edge);
                union(subsets, sourceParent, destinationParent);
                numEdges++;
            }
        }
        
        return minimumSpanningTree;
    }
    
    private static int find(Subset[] subsets, int vertex) {
        if (subsets[vertex].parent != vertex) {
            subsets[vertex].parent = find(subsets, subsets[vertex].parent);
        }
        
        return subsets[vertex].parent;
    }
    
    private static void union(Subset[] subsets, int x, int y) {
        int xRoot = find(subsets, x);
        int yRoot = find(subsets, y);
        
        if (subsets[xRoot].rank < subsets[yRoot].rank) {
            subsets[xRoot].parent = yRoot;
        } else if (subsets[xRoot].rank > subsets[yRoot].rank) {
            subsets[yRoot].parent = xRoot;
        } else {
            subsets[yRoot].parent = xRoot;
            subsets[xRoot].rank++;
        }
    }
    
    public static void main(String[] args) {
        List<Node> graph = new ArrayList<>();
        
        for (int i = 0; i < 5; i++) {
            graph.add(new Node(i));
        }
        
        // Ajouter les arêtes pour chaque nœud du graphe
        graph.get(0).addEdge(1, 2);
        graph.get(0).addEdge(3, 6);
        
        graph.get(1).addEdge(0, 2);
        graph.get(1).addEdge(2, 3);
        graph.get(1).addEdge(3, 8);
        graph.get(1).addEdge(4, 5);
        
        graph.get(2).addEdge(1, 3);
        graph.get(2).addEdge(4, 7);
        
        graph.get(3).addEdge(0, 6);
        graph.get(3).addEdge(1, 8);
        graph.get(3).addEdge(4, 9);
        
        graph.get(4).addEdge(1, 5);
        graph.get(4).addEdge(2, 7);
        graph.get(4).addEdge(3, 9);
        
        List<Edge> minimumSpanningTree = findMinimumSpanningTree(graph);
        
        System.out.println("Arêtes de l'arbre couvrant minimal :");
        for (Edge edge : minimumSpanningTree) {
            System.out.println(edge.source + " - " + edge.destination + " : " + edge.weight);
        }
    }
}