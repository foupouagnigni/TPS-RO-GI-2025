# Algorithme de Prim pour l'Arbre Couvrant Minimal

L'algorithme de Prim est un algorithme glouton utilisé pour trouver un arbre couvrant minimal dans un graphe pondéré non orienté.

## Fonctionnement de l'algorithme

1. **Entrée** : Un graphe pondéré non orienté.

2. Choisir un sommet de départ (source) dans le graphe.

3. Initialiser un ensemble vide pour stocker les sommets inclus dans l'arbre couvrant minimal.

4. Initialiser une file de priorité (par exemple, une file de priorité minimale) pour stocker les arêtes disponibles, triées par poids.

5. Marquer le sommet de départ comme visité et l'ajouter à l'ensemble des sommets de l'arbre couvrant minimal.

6. Pour chaque arête incidente au sommet de départ, ajouter l'arête à la file de priorité.

7. Tant que la file de priorité n'est pas vide :
   - Extraire l'arête de poids minimum de la file de priorité.
   - Si l'arête relie un sommet déjà inclus dans l'arbre couvrant minimal à un sommet non inclus, alors :
     - Ajouter l'arête à l'arbre couvrant minimal.
     - Marquer le sommet non inclus comme visité et l'ajouter à l'ensemble des sommets de l'arbre couvrant minimal.
     - Pour chaque arête incidente au sommet nouvellement visité, ajouter l'arête à la file de priorité.
   - Sinon, ignorer l'arête.

8. **Sortie** : L'ensemble des arêtes de l'arbre couvrant minimal.

## Exemple

Considérons le graphe suivant :
2    3
0 ---- 1
|      |
6      8
|      |
3 ---- 2
   9    5

1. Choisissons le sommet de départ 0.

2. L'ensemble des sommets inclus dans l'arbre couvrant minimal est initialisé avec le sommet de départ 0.

3. La file de priorité est initialisée avec les arêtes (0, 1) de poids 2 et (0, 2) de poids 6.

4. L'arête (0, 1) est extraite de la file de priorité et ajoutée à l'arbre couvrant minimal. Le sommet 1 est marqué comme visité et ajouté à l'ensemble des sommets de l'arbre couvrant minimal. Les arêtes (1, 2) de poids 3 et (1, 3) de poids 8 sont ajoutées à la file de priorité.

5. L'arête (1, 2) est extraite de la file de priorité et ajoutée à l'arbre couvrant minimal. Le sommet 2 est marqué comme visité et ajouté à l'ensemble des sommets de l'arbre couvrant minimal. L'arête (2, 3) de poids 8 est ajoutée à la file de priorité.

6. L'arête (2, 3) est extraite de la file de priorité et ajoutée à l'arbre couvrant minimal. Le sommet 3 est marqué comme visité et ajouté à l'ensemble des sommets de l'arbre couvrant minimal. Aucune autre arête n'est ajoutée à la file de priorité.

7. La file de priorité est maintenant vide. L'arbre couvrant minimal obtenu est [(0, 1), (1, 2), (2, 3)].

# Algorithme de Kruskal pour l'Arbre Couvrant Minimal

L'algorithme de Kruskal est un algorithme glouton utilisé pour trouver un arbre couvrant minimal dans un graphe pondéré non orienté.

## Fonctionnement de l'algorithme

1. **Entrée** : Un graphe pondéré non orienté représenté par une liste d'arêtes ou une matrice d'adjacence.

2. Trier toutes les arêtes du graphe par poids croissant.

3. Initialiser un ensemble vide pour stocker les arêtes de l'arbrecouvrant minimal.

4. Parcourir les arêtes triées dans l'ordre croissant :
   - Si l'ajout de l'arête à l'ensemble des arêtes de l'arbre couvrant minimal ne crée pas de cycle, alors ajouter l'arête à l'ensemble.
   - Sinon, ignorer l'arête.

5. **Sortie** : L'ensemble des arêtes de l'arbre couvrant minimal.

## Exemple

Considérons le graphe suivant :
2    3
0 ---- 1
|      |
6      8
|      |
3 ---- 2
   9    5

1. Trier les arêtes par poids croissant : [(0, 1, 2), (1, 2, 3), (0, 2, 6), (2, 3, 8), (0, 3, 9)].

2. Initialiser l'ensemble des arêtes de l'arbre couvrant minimal avec l'arête de poids minimum (0, 1, 2).

3. Parcourir les arêtes triées :
   - L'arête (1, 2, 3) peut être ajoutée sans créer de cycle. Ajouter l'arête à l'ensemble.
   - L'arête (0, 2, 6) peut être ajoutée sans créer de cycle. Ajouter l'arête à l'ensemble.
   - L'arête (2, 3, 8) peut être ajoutée sans créer de cycle. Ajouter l'arête à l'ensemble.
   - L'arête (0, 3, 9) peut être ajoutée sans créer de cycle. Ajouter l'arête à l'ensemble.

4. L'ensemble des arêtes de l'arbre couvrant minimal obtenu est [(0, 1, 2), (1, 2, 3), (0, 2, 6), (2, 3, 8)].


## Instructions de lancement

1. Assurez-vous d'avoir Java Development Kit (JDK) installé sur votre système. Vous pouvez vérifier cela en exécutant la commande `java -version` dans une fenêtre de terminal ou de ligne de commande.

2. Ouvrez une fenêtre de terminal ou de ligne de commande et naviguez jusqu'au répertoire où vous avez enregistré le fichier Java. Il s'agit de :
   - `KruskalAlgorithm.java` qui contient l'implémentation de l'algorithme de Kruskal avec la liste chainée pour la structure du graphe.
   - `KruskalAlgorithm2.java` qui contient l'implémentation de l'algorithme de Kruskal avec la matrice d'adjacence pour la structure du graphe.
   - `PrimAlgorithm.java` qui contient l'implémentation de l'algorithme de Prim avec la listes chainée pour la structure du graphe.
   - `PrimAlgorithm2.java` qui contient l'implémentation de l'algorithme de Kruskal avec la matrie d'adjacence pour la structure du graphe.

4. Compilez le code en utilisant l'une des commandes suivantes :
   - `javac KruskalAlgorithm.java` 
   - `javac KruskalAlgorithm2.java`
   - `javac PrimAlgorithm.java`
   - `javac PrimAlgorithm2.java`

5. Une fois que le code est compilé avec succès, exécutez le programme avec l'une des commandes suivantes :
`java KruskalAlgorithm`  
`java KruskalAlgorithm2`  
`java PrimAlgorithm`  
`java PrimAlgorithm2`  


6. Les arêtes de l'arbre couvrant de poids minimal seront affichées dans la sortie de la console.
