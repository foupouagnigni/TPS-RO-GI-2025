/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pluscourtchemin4;

import javafx.stage.Stage;

/**
 *
 * @author dell
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Interface_Dijkstra extends Stage {
    
    Pane root = new Pane();
  
    Label welcomeLabel = new Label("Bienvenue En Recherche Operationnelle ");
    Label algoDijkstraLabel = new Label("Algorithme Dijkstra");
    
    Button quitterButton = new Button("Quitter");
    Button retourButton = new Button("Retour");
        
    Label sommetsLabel = new Label("Sommets :");
    Label nombreSommetLabel = new Label("Nombre sommet");
    TextField nombreSommetTextField = new TextField();
    Button enregistrerButton = new Button("Enregistrer");
    Label parametreSommetLabel = new Label("Parametre Sommet");
                                            
    Label feedbackZoneLabel = new Label("FeedBackZone");
    Label ajouterSommetLabel = new Label("Ajouter ");
    
    TextField ajouterSommetTextField = new TextField(); 
    Button ajouterButton = new Button("Ajouter");
        Label modifierSommetLabel = new Label("Modifier");
        Label supprimerSommetLabel = new Label("Supprimer");
        TextField modifierSommetIdTextField = new TextField();
        TextField modifierSommetNomTextField = new TextField();
       Button modifierButton = new Button("Modifier");
       TextField supprimerSommetIdTextField = new TextField();
      Button supprimerButton = new Button("Supprimer");
      
      
      Label liensLabel = new Label("Liens:");
Label parametreLienLabel = new Label("Parametre Lien");
Label feedbackZoneLienLabel = new Label("FeedBackZone");
Label ajouterLienLabel = new Label("Ajouter ");
Label modifierLienLabel = new Label("Modifier");
Label supprimerLienLabel = new Label("Supprimer");


TextField ajouterLienTextField = new TextField();
TextField modifierLienIdTextField = new TextField();
TextField modifierLienNomTextField = new TextField();
TextField supprimerLienTextField = new TextField();
Button ajouterLienButton = new Button("Ajouter");
Button modifierLienButton = new Button("Modifier");
Button supprimerLienButton = new Button("Supprimer");
Label grapheLabel = new Label("Graphe :");
Button afficherGrapheButton = new Button("Afficher");
Label cheminLePlusCourtLabel = new Label("Chemin le Plus Court :");
Label feedbackZoneCheminLabel = new Label("FeedBackZone");
Label debutLabel = new Label("Début");

Label arriverLabel = new Label("Arriver");
TextField arriverTextField = new TextField();
Button calculerButton = new Button("Calculer");
Button afficherGrapheCheminButton = new Button("Afficher Graphe");
TextField debutTextField = new TextField();

    public Interface_Dijkstra(){
  
        welcomeLabel.setFont(new Font(33));
        welcomeLabel.setPrefHeight(68);
        welcomeLabel.setPrefWidth(590);
        welcomeLabel.setLayoutX(80);
        welcomeLabel.setLayoutY(8);

        algoDijkstraLabel.setFont(new Font(27));
        algoDijkstraLabel.setPrefHeight(68);
        algoDijkstraLabel.setPrefWidth(282);
        algoDijkstraLabel.setLayoutX(231);
        algoDijkstraLabel.setLayoutY(65);
        
        
        quitterButton.setFont(new Font(24));
        quitterButton.setPrefHeight(51);
        quitterButton.setPrefWidth(123);
        quitterButton.setLayoutX(594);
        quitterButton.setLayoutY(859);
        quitterButton.setMnemonicParsing(false);

        retourButton.setFont(new Font(24));
        retourButton.setPrefHeight(51);
        retourButton.setPrefWidth(123);
        retourButton.setLayoutX(15);
        retourButton.setLayoutY(859);
        retourButton.setMnemonicParsing(false);
        
        
        sommetsLabel.setFont(new Font(19));
        sommetsLabel.setPrefHeight(42);
        sommetsLabel.setPrefWidth(93);
        sommetsLabel.setLayoutX(52);
        sommetsLabel.setLayoutY(162);

        nombreSommetLabel.setFont(new Font(20));
        nombreSommetLabel.setPrefHeight(30);
        nombreSommetLabel.setPrefWidth(159);
        nombreSommetLabel.setLayoutX(162);
        nombreSommetLabel.setLayoutY(196);

        nombreSommetTextField.setPrefHeight(30);
        nombreSommetTextField.setPrefWidth(159);
        nombreSommetTextField.setLayoutX(355);
        nombreSommetTextField.setLayoutY(199);

        enregistrerButton.setFont(new Font(12));
        enregistrerButton.setLayoutX(557);
        enregistrerButton.setLayoutY(199);
        enregistrerButton.setMnemonicParsing(false);

        parametreSommetLabel.setFont(new Font(20));
        parametreSommetLabel.setPrefHeight(30);
        parametreSommetLabel.setPrefWidth(183);
        parametreSommetLabel.setLayoutX(162);
        parametreSommetLabel.setLayoutY(251);
        
        feedbackZoneLabel.setFont(new Font(20));
        feedbackZoneLabel.setPrefHeight(30);
        feedbackZoneLabel.setPrefWidth(183);
        feedbackZoneLabel.setLayoutX(355);
        feedbackZoneLabel.setLayoutY(251);

        ajouterSommetLabel.setFont(new Font(20));
        ajouterSommetLabel.setPrefHeight(30);
        ajouterSommetLabel.setPrefWidth(73);
        ajouterSommetLabel.setLayoutX(162);
        ajouterSommetLabel.setLayoutY(297);
        
        ajouterSommetTextField.setPrefHeight(30);
        ajouterSommetTextField.setPrefWidth(183);
        ajouterSommetTextField.setLayoutX(355);
        ajouterSommetTextField.setLayoutY(300);
        
        ajouterButton.setFont(new Font(12));
        ajouterButton.setPrefHeight(30);
        ajouterButton.setPrefWidth(100);
        ajouterButton.setLayoutX(565);
        ajouterButton.setLayoutY(300);
        ajouterButton.setMnemonicParsing(false);

        modifierSommetLabel.setFont(new Font(20));
        modifierSommetLabel.setPrefHeight(30);
        modifierSommetLabel.setPrefWidth(81);
        modifierSommetLabel.setLayoutX(158);
        modifierSommetLabel.setLayoutY(333);

        supprimerSommetLabel.setFont(new Font(20));
        supprimerSommetLabel.setPrefHeight(30);
        supprimerSommetLabel.setPrefWidth(93);
        supprimerSommetLabel.setLayoutX(158);
        supprimerSommetLabel.setLayoutY(363);

        modifierSommetIdTextField.setPrefHeight(25);
        modifierSommetIdTextField.setPrefWidth(41);
        modifierSommetIdTextField.setLayoutX(355);
        modifierSommetIdTextField.setLayoutY(336);

         modifierSommetNomTextField.setPrefHeight(25);
        modifierSommetNomTextField.setPrefWidth(41);
        modifierSommetNomTextField.setLayoutX(463);
        modifierSommetNomTextField.setLayoutY(336);

         modifierButton.setFont(new Font(12));
        modifierButton.setPrefHeight(30);
        modifierButton.setPrefWidth(100);
        modifierButton.setLayoutX(562);
        modifierButton.setLayoutY(336);
        modifierButton.setMnemonicParsing(false);

        supprimerSommetIdTextField.setPrefHeight(30);
        supprimerSommetIdTextField.setPrefWidth(183);
        supprimerSommetIdTextField.setLayoutX(355);
        supprimerSommetIdTextField.setLayoutY(366);

        supprimerButton.setFont(new Font(12));
        supprimerButton.setPrefHeight(25);
        supprimerButton.setPrefWidth(73);
        supprimerButton.setLayoutX(557);
        supprimerButton.setLayoutY(366);
        supprimerButton.setMnemonicParsing(false);
        
        liensLabel.setFont(new Font(19));
liensLabel.setPrefHeight(42);
liensLabel.setPrefWidth(93);
liensLabel.setLayoutX(45);
liensLabel.setLayoutY(420);

parametreLienLabel.setFont(new Font(20));
parametreLienLabel.setPrefHeight(30);
parametreLienLabel.setPrefWidth(183);
parametreLienLabel.setLayoutX(162);
parametreLienLabel.setLayoutY(462);

feedbackZoneLienLabel.setFont(new Font(20));
feedbackZoneLienLabel.setPrefHeight(30);
feedbackZoneLienLabel.setPrefWidth(183);
feedbackZoneLienLabel.setLayoutX(355);
feedbackZoneLienLabel.setLayoutY(462);

ajouterLienLabel.setFont(new Font(20));
ajouterLienLabel.setPrefHeight(30);
ajouterLienLabel.setPrefWidth(73);
ajouterLienLabel.setLayoutX(162);
ajouterLienLabel.setLayoutY(511);

modifierLienLabel.setFont(new Font(20));
modifierLienLabel.setPrefHeight(30);
modifierLienLabel.setPrefWidth(81);
modifierLienLabel.setLayoutX(164);
modifierLienLabel.setLayoutY(549);

supprimerLienLabel.setFont(new Font(20));
supprimerLienLabel.setPrefHeight(30);
supprimerLienLabel.setPrefWidth(93);
supprimerLienLabel.setLayoutX(164);
supprimerLienLabel.setLayoutY(588);

ajouterLienTextField.setLayoutX(345);
ajouterLienTextField.setLayoutY(514);

modifierLienIdTextField.setPrefHeight(25);
modifierLienIdTextField.setPrefWidth(41);
modifierLienIdTextField.setLayoutX(345);
modifierLienIdTextField.setLayoutY(552);

modifierLienNomTextField.setPrefHeight(25);
modifierLienNomTextField.setPrefWidth(41);
modifierLienNomTextField.setLayoutX(453);
modifierLienNomTextField.setLayoutY(552);

supprimerLienTextField.setLayoutX(345);
supprimerLienTextField.setLayoutY(591);

ajouterLienButton.setMnemonicParsing(false);
ajouterLienButton.setLayoutX(564);
ajouterLienButton.setLayoutY(519);

modifierLienButton.setMnemonicParsing(false);
modifierLienButton.setLayoutX(561);
modifierLienButton.setLayoutY(555);

supprimerLienButton.setMnemonicParsing(false);
supprimerLienButton.setPrefHeight(25);
supprimerLienButton.setPrefWidth(73);
supprimerLienButton.setLayoutX(556);
supprimerLienButton.setLayoutY(585);

grapheLabel.setFont(new Font(19));
grapheLabel.setPrefHeight(42);
grapheLabel.setPrefWidth(93);
grapheLabel.setLayoutX(45);
grapheLabel.setLayoutY(644);

afficherGrapheButton.setMnemonicParsing(false);
afficherGrapheButton.setPrefHeight(25);
afficherGrapheButton.setPrefWidth(73);
afficherGrapheButton.setLayoutX(557);
afficherGrapheButton.setLayoutY(653);

cheminLePlusCourtLabel.setFont(new Font(20));
cheminLePlusCourtLabel.setPrefHeight(30);
cheminLePlusCourtLabel.setPrefWidth(206);
cheminLePlusCourtLabel.setLayoutX(45);
cheminLePlusCourtLabel.setLayoutY(710);

feedbackZoneCheminLabel.setFont(new Font(20));
feedbackZoneCheminLabel.setPrefHeight(30);
feedbackZoneCheminLabel.setPrefWidth(183);
feedbackZoneCheminLabel.setLayoutX(321);
feedbackZoneCheminLabel.setLayoutY(710);

debutLabel.setFont(new Font(20));
debutLabel.setPrefHeight(30);
debutLabel.setPrefWidth(61);
debutLabel.setLayoutX(92);
debutLabel.setLayoutY(757);

debutTextField.setPrefHeight(25);
debutTextField.setPrefWidth(41);
debutTextField.setLayoutX(184);
debutTextField.setLayoutY(760);

arriverLabel.setFont(new Font(20));
arriverLabel.setPrefHeight(30);
arriverLabel.setPrefWidth(61);
arriverLabel.setLayoutX(251);
arriverLabel.setLayoutY(760);

arriverTextField.setPrefHeight(25);
arriverTextField.setPrefWidth(41);
arriverTextField.setLayoutX(335);
arriverTextField.setLayoutY(763);

calculerButton.setMnemonicParsing(false);
calculerButton.setLayoutX(443);
calculerButton.setLayoutY(763);

afficherGrapheCheminButton.setMnemonicParsing(false);
afficherGrapheCheminButton.setLayoutX(542);
afficherGrapheCheminButton.setLayoutY(763);
        
    // Ajout des éléments à la scène
    root.getChildren().addAll(
            welcomeLabel,
            algoDijkstraLabel,
            quitterButton,
            retourButton,
            sommetsLabel,
            nombreSommetLabel,
            nombreSommetTextField,
            enregistrerButton,
            parametreSommetLabel,
            feedbackZoneLabel,
            ajouterSommetLabel,
            ajouterSommetTextField,
            ajouterButton,
            modifierSommetLabel,
            supprimerSommetLabel,
            modifierSommetIdTextField,
            modifierSommetNomTextField,
            modifierButton,
            supprimerSommetIdTextField,
            supprimerButton,
            liensLabel, 
            parametreLienLabel,
            feedbackZoneLienLabel, 
            ajouterLienLabel, 
            modifierLienLabel,
            supprimerLienLabel,
            ajouterLienTextField,
            modifierLienIdTextField,
            modifierLienNomTextField,
            supprimerLienTextField,
            ajouterLienButton,
            modifierLienButton,
            supprimerLienButton,
            grapheLabel,
            afficherGrapheButton,
            cheminLePlusCourtLabel,
            feedbackZoneCheminLabel,
            debutLabel, 
            debutTextField,
            arriverLabel,
            arriverTextField,
            calculerButton,
            afficherGrapheCheminButton
            );

    // Configuration de la scène
    Scene scene = new Scene(root,744, 924);

    // Affichage de la scène
    setScene(scene);
    
}

} 

