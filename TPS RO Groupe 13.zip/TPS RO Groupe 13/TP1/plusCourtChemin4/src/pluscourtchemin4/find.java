/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pluscourtchemin4;

/**
 *
 * @author dell
 */
public class find {
    
    
    public static int findIndexSommet(String sommet,String NomSommet []){
        
        int index=-1;    
        for (int i=0;i<NomSommet.length;i++){
                if(NomSommet[i]==sommet){index=i;}
                                            }
        return(index);
        }
    
    public  static int [] IndexSommetPcChemin(String Tcpc[],String NomSommet []){
        int IndexSommetCheminPlusCourt[]=new int[Tcpc.length];
        //tcpc = tableau chemin le plus court....  
        for (int i=0;i<Tcpc.length;i++){
                IndexSommetCheminPlusCourt[i]=findIndexSommet(Tcpc[i],NomSommet);
            }
        return(IndexSommetCheminPlusCourt);
        }
        
    
}
