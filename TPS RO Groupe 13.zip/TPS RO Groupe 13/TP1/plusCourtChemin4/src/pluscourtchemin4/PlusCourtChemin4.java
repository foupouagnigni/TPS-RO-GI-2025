/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pluscourtchemin4;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.Stage;
/**
 *
 * @author dell
 */
public class PlusCourtChemin4 extends Application {
    
   static int sommet=7;
   static  String NomSommet[]=new String[]{"a","b","c","d","e","f","g"};
  // static String  NomSommetCheminPlusCourt[]=new String[]{"A","D","C","B"};
   static String  NomSommetCheminPlusCourt2[]=new String[]{};
   
   static  int Madj[][]={   {0,2,0,0,0,0,2},
                            {2,0,0,10,2,0,15},
                            {0,0,0,7,10,12,5},
                            {0,10,7,0,1,0,3},
                            {0,2,10,1,0,11,0},
                            {0,0,12,0,11,0,0},
                            {2,15,5,3,0,0,0},
                            };
   static public  MAdj mAdj= new MAdj(sommet,NomSommet,Madj); 
   
   
   static String fileName="GenGraph";
   static String fileName2="GenGraphCPC";
   static String Depart="a";
   static String Arriver="c";
   
   Interface_Accueil accueil=new Interface_Accueil();
   Interface_Dijkstra interfaceDijkstra=new Interface_Dijkstra();
       
   public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
      launch(args);
   }
    @Override
    public void start(Stage primaryStage) throws Exception {
        accueil.show();
        accueil.quitButton.setOnAction(new EventHandler <ActionEvent>(){
        @Override 
        public void handle(ActionEvent event){
        accueil.close();
        }});
        accueil.dijkstraButton.setOnAction(new EventHandler <ActionEvent>(){
        @Override 
        public void handle(ActionEvent event){
        accueil.close();
        interfaceDijkstra.show();
        
        }});
        
        
      
        
        
        
        
        
        
        GenDotPngGraph genererGraphe=new GenDotPngGraph();
     genererGraphe.genererGraph(fileName, sommet, NomSommet, Madj);
        // creation des sommets
     for (int i=0;i<sommet;i++){
         Vertex vertex=new Vertex(NomSommet[i]);
               }
     
     // attribution des liens 
      for (int i=0;i<sommet;i++){
                for(int j=0;j<sommet;j++){
              if(Madj[i][j]!=0){  
                 Vertex.getInstances().get(i).addNeighbour
                (new Edge(Madj[i][j],Vertex.getInstances().get(i)
                ,Vertex.getInstances().get(j)));   
                
                }}}
      
        Dijkstra dijkstra = new Dijkstra();

        Vertex VDepart=Vertex.getInstances().get(find.findIndexSommet(Depart,NomSommet));
        Vertex VArriver=Vertex.getInstances().get(find.findIndexSommet(Arriver,NomSommet));
       
        dijkstra.computePath(VDepart);  
        
         List<Vertex> Tcpc=dijkstra.getShortestPathTo(VArriver);
         String  NomSommetCheminPlusCourt2[]=new String[Tcpc.size()];
         
         for (int i =0;i<Tcpc.size();i++){
         NomSommetCheminPlusCourt2[i]=Tcpc.get(i).toString();
         System.out.print(NomSommetCheminPlusCourt2[i]);
         }
        
        
        genererGraphe.genererGraphPChemin(fileName2, sommet, NomSommet, Madj,NomSommetCheminPlusCourt2);
    
        
    }
      
   
        
        }

      
      