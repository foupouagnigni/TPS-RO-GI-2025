/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pluscourtchemin4;

/**
 *
 * @author dell
 */
public class MAdj {
    
    int sommet;
    String NomSommet[]=new String [sommet];
    int Madj [][]= new int [sommet][sommet];;
  public MAdj(int sommet,String NomSommet[],int Madj[][])
            {
            this.sommet=sommet;
            this.NomSommet=NomSommet;
            this.Madj=Madj;
            }
    
    
    
    
    
    
    
}
