
package pluscourtchemin4;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class Interface_Accueil extends Stage {

    Pane pane=new Pane();
    Label welcomeLabel = new Label("Bienvenue En Recherche Operationnelle");
    Label algorithmChoiceLabel = new Label("Choix De L'Algorithme");
       
    Button dijkstraButton = new Button("Dijkstra");
    Button primButton = new Button("Prime");
    Button kruskalButton = new Button("Kruskal");
    Button quitButton = new Button("Quitter");
        
    public Interface_Accueil(){
         // Ajouter les éléments au conteneur principal
        pane.getChildren().addAll(welcomeLabel, algorithmChoiceLabel, dijkstraButton, primButton, kruskalButton, quitButton);

        // Gérer les labels
         welcomeLabel.setFont(new Font(33));
        welcomeLabel.setPrefHeight(68);
        welcomeLabel.setPrefWidth(590);
         algorithmChoiceLabel.setFont(new Font(27));
        algorithmChoiceLabel.setPrefHeight(68);
        algorithmChoiceLabel.setPrefWidth(282);

        // Gérer les boutons
         dijkstraButton.setFont(new Font(24));
        dijkstraButton.setPrefHeight(51);
        dijkstraButton.setPrefWidth(123);
        primButton.setFont(new Font(24));
        primButton.setPrefHeight(51);
        primButton.setPrefWidth(123);
       kruskalButton.setFont(new Font(24));
        kruskalButton.setPrefHeight(51);
        kruskalButton.setPrefWidth(123);
        quitButton.setFont(new Font(24));
        quitButton.setPrefHeight(51);
        quitButton.setPrefWidth(123);

        // Positionner les éléments
        
        welcomeLabel.setLayoutX(80);
        welcomeLabel.setLayoutY(8);
        algorithmChoiceLabel.setLayoutX(234);
        algorithmChoiceLabel.setLayoutY(110);
        dijkstraButton.setLayoutX(101);
        dijkstraButton.setLayoutY(233);
        primButton.setLayoutX(311);
        primButton.setLayoutY(233);
        kruskalButton.setLayoutX(506);
        kruskalButton.setLayoutY(233);
        quitButton.setLayoutX(599);
        quitButton.setLayoutY(370);

        // Définir mnemonicParsing pour les boutons
        dijkstraButton.setMnemonicParsing(false);
        primButton.setMnemonicParsing(false);
        kruskalButton.setMnemonicParsing(false);
        quitButton.setMnemonicParsing(false);

        
        // Créer la scène et la configurer
        Scene scene = new Scene(pane, 744, 435);
        setScene(scene);
        setTitle("Recherche Operationnelle");
       
    }
        
    }
    
   
    
        
       