/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pluscourtchemin4;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author dell
 */
public class GenDotPngGraph {
    
    public void genererGraph(String fileName, int sommet,String NomSommet[],int Madj[][]){
    
    GraphPrinter gp = new GraphPrinter(fileName);


// construction du graphe selon la matrice d'adjacence
     for (int i=0;i<sommet;i++){
                for(int j=0;j<sommet;j++){
                if(Madj[i][j]!=0){
                  gp.addln(NomSommet[i]+"->"+NomSommet[j]+"[label=\""+Madj[i][j]+"\"];"); 
                }
                  }
                    }
     
     gp.print();

}
    
    public void genererGraphPChemin(String fileName, int sommet,String NomSommet[],int Madj[][],String Tcpc[]){
    
        int [] indexSommetPcChemin= find.IndexSommetPcChemin(Tcpc,NomSommet);
    GraphPrinter gp = new GraphPrinter(fileName); 
    int i1=-1,j1=-1;
    for (int i=0;i<sommet;i++){
        
        //correspondance des indexs 
       for (int u=0;u<indexSommetPcChemin.length;u++){
           if(i==indexSommetPcChemin[u])
           {
               i1=i;
               if(u==indexSommetPcChemin.length-1){j1=-1;}
               else {j1=indexSommetPcChemin[u+1];}
            }
           
                }
        
       
        for(int j=0;j<sommet;j++){               
          if(Madj[i][j]!=0){          
                    
                if (i==i1 && j==j1) {
                  
                        gp.addln(NomSommet[i]+"->"+NomSommet[j]+"[label=\""+Madj[i][j]+"\"color=green];");
                            
                    }
                
                    else { gp.addln(NomSommet[i]+"->"+NomSommet[j]+"[label=\""+Madj[i][j]+"\"];");
                            }
                    
                }
                  }
                    }
        
     
     gp.print();

}
}