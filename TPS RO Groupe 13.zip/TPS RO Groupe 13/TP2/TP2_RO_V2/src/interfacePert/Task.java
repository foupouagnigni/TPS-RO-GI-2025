package interfacePert;
public class Task {
    private String activity;
    private int duration;
    private String dependency;
    private int earliestStart;
    private int earliestFinish;
    private int latestStart;
    private int latestFinish;
    private int margin;
    private boolean critical;

    public Task(String activity, int duration, String dependency) {
        this.activity = activity;
        this.duration = duration;
        this.dependency = dependency;
    }
    public Task(String activity,
            int duration,
            String dependency,
            int earliestStart,
     int earliestFinish,
     int latestStart,
    int latestFinish,
    int margin,
    boolean critical)
    {     this.activity=activity;
         this.duration=duration;
           this.dependency=dependency;
       this.earliestStart=earliestStart;
     this.earliestFinish=earliestFinish;
     this.latestStart=latestStart;
    this.latestFinish=latestFinish;
    this.margin=margin;
    this.critical=critical;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getDependency() {
        return dependency;
    }

    public void setDependency(String dependency) {
        this.dependency = dependency;
    }

    public int getEarliestStart() {
        return earliestStart;
    }

    public void setEarliestStart(int earliestStart) {
        this.earliestStart = earliestStart;
    }

    public int getEarliestFinish() {
        return earliestFinish;
    }

    public void setEarliestFinish(int earliestFinish) {
        this.earliestFinish = earliestFinish;
    }

    public int getLatestStart() {
        return latestStart;
    }

    public void setLatestStart(int latestStart) {
        this.latestStart = latestStart;
    }

    public int getLatestFinish() {
        return latestFinish;
    }

    public void setLatestFinish(int latestFinish) {
        this.latestFinish = latestFinish;
    }

    public int getMargin() {
        return margin;
    }

    public void setMargin(int margin) {
        this.margin = margin;
    }

    public boolean isCritical() {
        return critical;
    }

    public void setCritical(boolean critical) {
        this.critical = critical;
    }
}
