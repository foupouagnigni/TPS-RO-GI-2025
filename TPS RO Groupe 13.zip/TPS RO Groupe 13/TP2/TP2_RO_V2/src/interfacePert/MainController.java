package interfacePert;

import java.util.Arrays;
import tp2_ro.PERT;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import tp2_ro.Tache;

public class MainController {

    PERT pert= new PERT();
    @FXML
    private TextField taskField;

    @FXML
    private TextField durationField;

    @FXML
    private TextField dependencyField;

    @FXML
    private Button executeButton;
    @FXML
    private Label ResultatLDuréeProjet;
 
    @FXML
    private Label ResultatLTachesCritiques;
 

    @FXML
    private TableView<Task> taskTable;

    @FXML
    private TableColumn<Task, String> activityColumn;

    @FXML
    private TableColumn<Task, Integer> durationColumn;

    @FXML
    private TableColumn<Task, String> dependencyColumn;

    @FXML
    private TableColumn<Task, Integer> earlyStartColumn;

    @FXML
    private TableColumn<Task, Integer> lateStartColumn;

    @FXML
    private TableColumn<Task, Integer> earlyFinishColumn;

    @FXML
    private TableColumn<Task, Integer> lateFinishColumn;

    @FXML
    private TableColumn<Task, Integer> slackColumn;

    @FXML
    private TableColumn<Task, Boolean> criticalColumn;

    private final ObservableList<Task> tasks = FXCollections.observableArrayList();

    @FXML
    public void addTask() {
        String taskName = taskField.getText();
        
        if (taskName.isEmpty()) {
            showAlert("Entrer le nom de la tâche et Ajoutez au moins deux(02) tâche avant d'exécuter l'algorithme PERT.");    
        }
        else{
            
        String duration = durationField.getText();
        String dependency = dependencyField.getText();
        
        if(dependency.length()==0)
            {
                
                dependency="nulle";}
        Task task = new Task(taskName,Integer.parseInt(duration), dependency);
        tasks.add(task);
        PERT.listOfListsTask.add(
          Arrays.asList(taskName,"", duration,dependency));
        System.out.println(PERT.listOfListsTask);
        //System.out.println("dependancy Value"+dependency);

        taskField.clear();
        durationField.clear();
        dependencyField.clear();

        updateTaskTable();
        executeButton.setDisable(false);
    }
    }
    public void resetTask(){
        PERT.listOfListsTask.clear();
        tasks.clear();
        pert.CheminCritique.clear();
        executeButton.setDisable(false);
        
        taskField.clear();
        durationField.clear();
        dependencyField.clear();
        ResultatLDuréeProjet.setText("..........");
        ResultatLTachesCritiques.setText("..........");
       
        
    }
    @FXML
    public void executePERT() {
        if (tasks.isEmpty()) {
            showAlert("Ajoutez au moins une tâche avant d'exécuter l'algorithme PERT.");
            return;
        }
        else{

      
        pert.CalculPert(PERT.listOfListsTask);
        updateTaskTablePert();
        
        Tache tache = new Tache();
        int duréeMinimaleProjet=tache.getInstances().get(Tache.IdFIN).DPTot;
        ResultatLDuréeProjet.setText(String.valueOf(duréeMinimaleProjet));
        ResultatLTachesCritiques.setText(pert.CheminCritique.toString());
       
        executeButton.setDisable(true);
    }
    }
    private void updateTaskTable() {
        activityColumn.setCellValueFactory(new PropertyValueFactory<>("activity"));
        durationColumn.setCellValueFactory(new PropertyValueFactory<>("duration"));
        dependencyColumn.setCellValueFactory(new PropertyValueFactory<>("dependency"));
        earlyStartColumn.setCellValueFactory(new PropertyValueFactory<>("earliestStart"));
        lateStartColumn.setCellValueFactory(new PropertyValueFactory<>("latestStart"));
        earlyFinishColumn.setCellValueFactory(new PropertyValueFactory<>("earliestFinish"));
        lateFinishColumn.setCellValueFactory(new PropertyValueFactory<>("latestFinish"));
        slackColumn.setCellValueFactory(new PropertyValueFactory<>("margin"));
        criticalColumn.setCellValueFactory(new PropertyValueFactory<>("critical"));

        taskTable.setItems(tasks);
        
    }

   private void updateTaskTablePert() {
        
        tasks.clear();
        activityColumn.setCellValueFactory(new PropertyValueFactory<>("activity"));
        durationColumn.setCellValueFactory(new PropertyValueFactory<>("duration"));
        dependencyColumn.setCellValueFactory(new PropertyValueFactory<>("dependency"));
        earlyStartColumn.setCellValueFactory(new PropertyValueFactory<>("earliestStart"));
        lateStartColumn.setCellValueFactory(new PropertyValueFactory<>("latestStart"));
        earlyFinishColumn.setCellValueFactory(new PropertyValueFactory<>("earliestFinish"));
        lateFinishColumn.setCellValueFactory(new PropertyValueFactory<>("latestFinish"));
        slackColumn.setCellValueFactory(new PropertyValueFactory<>("margin"));
        criticalColumn.setCellValueFactory(new PropertyValueFactory<>("critical"));

        for(int i=0;i<PERT.listOfListsTask.size();i++)
        {
            
             Tache tache =Tache.getInstances().get(i);
           
                Task task = new Task(
                    tache.nom,
                    tache.durée,
                    tache.Lantecedant.toString(),
                    tache.DateDebutPlusTot,
                    tache.DateFinPlusTot,
                    tache.DateDebutPlusTard,
                    tache.DateFinPlusTard,
                    tache.marge,
                    tache.critique);
            
            tasks.add(task);
            
        }
        
       
        taskTable.setItems(tasks);
        
    }


    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
       
    }
}