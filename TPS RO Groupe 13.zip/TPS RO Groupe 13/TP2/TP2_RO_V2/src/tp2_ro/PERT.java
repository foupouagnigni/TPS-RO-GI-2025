/*
 Dans ce TP , on suppose que les tâches sont classées par ordre d'appartition.
 Chaque tache a un nom unique . 
 */
package tp2_ro;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @Mowoum Foupouagnigni
 */
public class PERT {

   String [] LDébut;
  public static String Fin;
  public static List<List<String>> listOfListsTask = new ArrayList<>();
  static int NbTaches=0;
  static int colMTache=0;
   String MTache[][];
   static int DuréeTotale=0;
   public static List<String> CheminCritique=new ArrayList<>();
   //Nom tache // Nature // Durée // antécédants 
   
   public void CalculPert(List<List<String>> listOfListsTask){
        
     // String MTache[][]=remplissageMatrice_ListTache(listOfListsTask);
       NbTaches=listOfListsTask.size();
       colMTache=listOfListsTask.get(0).size();
       // creation des objets tâches 
       CreationObjetsTaches(listOfListsTask);
       //
       Listesuivants(); //ok
       //mise à jour des Debut et antecedant de chaque tache (si on a 1 seul antécédant)
       ChercherTacheFin();//ok
       DatesPlusTot();//ok
       antecedantsNonChoisi();//ok
       DatesPlusTard();//ok
       ResetMarges();
       UpdateDates();
      afficher_Taches();
       afficher_Taches_critique();
       
    }
   
  
    //************Creation des objets tâches à partir de la matrice**********
    public static  void CreationObjetsTaches(List<List<String>> listOfListsTask){
    for (int i=0;i<NbTaches;i++){
            //on converti la colone antécédant en tableau . 
     ArrayList <String> Lantecedants=new ArrayList<>();
     boolean Debut=false;
         // MTache[i][3].split(",").length represente le nombre d'antecendants.
     for(int j=0;j<listOfListsTask.get(i).get(3).split(",").length;j++)
     {Lantecedants.add(listOfListsTask.get(i).get(3).split(",")[j].replaceAll("\\s", ""));
    // System.out.println("liste de mes antécédants"+Lantecedants.toString());
     }
     
    
     
     // si la tache n'a pas d'antécédant ,on indique que elle est un début . 
     if(Lantecedants.get(0)=="nulle")
     {  
         Debut=true;
         System.out.println("valeur début"+Debut);}
        
    
     // on creait l'objet tache : id , Nom, Nature , Durée,Antécédants...
     Tache tache=new Tache(i,listOfListsTask.get(i).get(0),listOfListsTask.get(i).get(1),Integer.parseInt(listOfListsTask.get(i).get(2)),Lantecedants,Debut);
    
     System.out.println("on vient de creer la tâche "+tache.nom+" valeur de debut :"+tache.Debut);
    }
    
    }
    
    
    //****************** mise à jour de la liste des suivants de chaque tâches************* 
   public static void Listesuivants()
   {  for (int i=0;i<NbTaches;i++)
       {
           Tache tache =Tache.getInstances().get(i);
           System.out.println("je suis dans la fonction ListeSuivant de la tâche: "+tache.nom);
           tache.suivant();
           
       }
                                        
      }
   
   //********************* recherche de la tache de fin du projet***********
   public static void ChercherTacheFin(){
   
       for (int i=0;i<NbTaches;i++)
       {
           Tache tache =Tache.getInstances().get(i);
       if( tache.Lsuivant.size()==0){
            Tache.IdFIN=i;
            System.out.println("je suis la tache de fin "+tache.nom+" d'id: "+i);
            break;
                                    }
       }
                                        }
   
   //*********************recherche de la date la plus tôt de chaque tâches***
   public static void DatesPlusTot(){
       for (int i=0;i<NbTaches;i++){
         Tache tache=Tache.getInstances().get(i);
         tache.DatePlusTot();
                                    }
       }
   
   //******************verification si j'ai  un suivant qui na pas choisi une tache  comme antécédant********
   public static void antecedantsNonChoisi()
   {
        for (int i=0;i<NbTaches;i++){
         Tache tache=Tache.getInstances().get(i);
         tache.antecedantNonChoisi();
                                    }
   }
   
   //*******************recherche de la date la plus tard de chaque tache *****
   public static void DatesPlusTard(){
       for (int i=NbTaches-1;i>=0;i--){
         Tache tache=Tache.getInstances().get(i);
         tache.DatePlusTard();
                                    }
       }
   
   //***********************Actualisation des marges**************/
   public static void ResetMarges()
   {
        for (int i=0;i<NbTaches;i++){
         Tache tache=Tache.getInstances().get(i);
        
         tache.resetMarge();
                                }
   }
   public static void UpdateDates()
   {
        for (int i=0;i<NbTaches;i++){
            Tache tache=Tache.getInstances().get(i);
            if(tache.Debut==false){
                
         tache.updateDate();}
                                    }
   }
   
   
   
   
   
   /*************Affichage des tâches*******************/
   public static void afficher_Taches(){
        
       for (int i=0;i<NbTaches;i++){
         Tache tache=Tache.getInstances().get(i); 
         String nomSuivant="";
        String nomAntecedant="";
        
        ArrayList <String> ListNomAntecedant=new ArrayList<>();
        ArrayList <String> ListNomSuivant=new ArrayList<>();
      try{     
         if(tache.Lantecedant.get(0)!="nulle")
         {ListNomAntecedant=tache.Lantecedant;}
         else{ListNomAntecedant.add("aucun");}
         
       if(tache.antecedant.nom!="nulle"){nomAntecedant=tache.antecedant.nom;}
         else{nomAntecedant="aucun";}

         
         if(tache.suivant.nom!=null)
         {   ListNomSuivant=tache.Lsuivant;
             nomSuivant=tache.suivant.nom;}
         else{  ListNomSuivant.add("aucun");
                nomSuivant="aucun";}}
          catch(Exception e){}   
        System.out.println(
                "Tache: "+i+"Nom: "+tache.nom+
                " DPTot: "+tache.DPTot+" DPTard: "+tache.DPTard+
                " marge: "+tache.marge+" Lantedant: "+ListNomAntecedant+
                " antécedant choisi: "+nomAntecedant+
               " Lsuivant: "+ListNomSuivant+" suivant choisi: "+nomSuivant+
               " AntécédantNonChoisi: "+tache.antecedantNonChoisi);
         
   }}

   
   
   /*****************************affichage des tâches critiques*********/ 
   public static void afficher_Taches_critique()
   {
     System.out.println("les tâches critiques sont:");
       for (int i=0;i<NbTaches;i++)
       {
         Tache tache=Tache.getInstances().get(i);
         int marge=tache.marge;
         if(marge==0){
             System.out.println(tache.nom);
             CheminCritique.add(tache.nom);
                    }
        }
       DuréeTotale=Tache.getInstances().get(Tache.IdFIN).DPTot;
       
       System.out.println("Durée totale: "+DuréeTotale);
   }
   
   /************FIN**********/ 
   
   }
              


    
    
    
    
       
    
    
    
    
    

