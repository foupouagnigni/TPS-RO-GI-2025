/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_ro;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @Mowoum Foupouagnigni
 */
public class Tache {
    public static int  num=0;
    private static List<Tache> instances=new ArrayList<>();

    public static List<Tache> getInstances() {
        return instances;
    }
    
    public static int IdFIN;
    
    public int id;
    public String nom;
    public String nature;
    public int durée;
    public int DPTot=0;
    public int DPTard=0;
    public int marge=DPTard-DPTot;
    public boolean critique=false; 
    
    public int DateDebutPlusTot=0;
    public int DateDebutPlusTard=0;
    public int DateFinPlusTot=0;
    public int DateFinPlusTard=0;
    public ArrayList <String> Lantecedant=new ArrayList<>();
    public ArrayList <String> Lsuivant=new ArrayList<>();
   // public String [] Lantecedant;
   // public String [] Lsuivant;
    
    public Tache antecedant;
    public Tache suivant;
    
    

    public Tache getAntecedant() {
        if(antecedant==null){
            antecedant=new Tache();
        }
        return antecedant;
    }

    

    public Tache getSuivant() {
        if(suivant==null){
            suivant=new Tache();
        }
        return suivant;
    }

    public void setSuivant(Tache suivant) {
        this.suivant = suivant;
    }
    
    public boolean antecedantNonChoisi=false;
    public boolean Debut=false;
    
    public void EntrezListeSuivant(){}
    public void Debut_au_plus_tôt(){}
    
    public Tache(){}
    public Tache(int id , String nom,String nature,int durée,ArrayList<String> Lantecedant,boolean Debut)
    {
        
        this.id=id;
        this.nom=nom;
        this.nature=nature;
        this.durée=durée;
        this.Lantecedant=Lantecedant;
        this.Debut=Debut;
        num=num+1;
        instances.add(this);
        
    }
   
   // recuperation de l'id d'une tache . 
   public static int getIdTacheByName(String nomTache){
        int IdTache=-1;// if id Tache keep -1 , its means the instance Tache does not exits;
       System.out.println("je suis dans getIdTacheByName je cherche l'id de la tache:"+nomTache);
        for (int i=0;i<instances.size();i++){
            Tache tache=instances.get(i);
        //   System.out.println("                          je suis dans le for à i: "+i+" a la tache: "+tache+" qui a pour nom "+tache.nom +" le nom la tâche à trouver est : "+nomTache);
           
       if(tache.nom.equals(nomTache)){
       IdTache=tache.id;
       System.out.println("Trouver : la tache "+nomTache+" a pour id "+IdTache);
       break;
           
       }
       }
        if(IdTache==-1){
         System.out.println("IdTache=-1 pour la tache: "+nomTache);
         
       }
       return(IdTache);
   }
   
   public  void DatePlusTot(){
       
       
      
       //si on est à une tache de début , sa Date la plus tôt est sa durée
       if( Debut==true){DPTot=durée;}
       
       else{
       // si on a 1 seul antécédant 
           if(Lantecedant.size()==1 && Lantecedant.get(0)!="nulle"){
                
                antecedant=instances.get(getIdTacheByName(Lantecedant.get(0)));
                DPTot=antecedant.DPTot+durée;
                antecedant.suivant=this;
                
           }
           else
           {   // dans le cas où il y'a plusieurs antécédants
               //  choix de l'antecedant 
               // pour chaque antécédant, on calcul la date le plus tot. et on stocke dans une liste 
                ArrayList <Integer> valeursDpt = new ArrayList<>(); 
               for(int j=0;j<Lantecedant.size();j++)
               {
                   Tache antécédant=instances.get(getIdTacheByName(Lantecedant.get(j)));
                   int DatePlusTot=antécédant.DPTot + durée;
                   
                   valeursDpt.add( DatePlusTot);
                   antécédant.suivant=this;
               }
               System.out.println("valeurs des DatesPlus tot: "+valeursDpt.toString());
               // on retient l'antécédant qui donne la date le plus tot la plus grande. 
               int max=valeursDpt.get(0);// initialisation de max
               int Idmax=0;
               for(int k=0;k<valeursDpt.size();k++)
               {
                   if(max<valeursDpt.get(k))
                   {max=valeursDpt.get(k);
                    Idmax=k;
                   }  
               }
               // on affecte l'antécédant choisi et  date la plus tot trouver à la tache . 
               antecedant=instances.get(getIdTacheByName(Lantecedant.get(Idmax)));
               DPTot=antecedant.DPTot+durée;
               
           }
       }
       }
   
   
   public void suivant()
   {
       //System.out.println("je suis à la tâche "+nom);
        if(Debut==false)
        {   // nb :si la tache a un seul antécédant  , alors il est suivant de  cet antécédant. 
            System.out.println("je suis à le if Debut==false");
            System.out.println("Lantecedant= "+Lantecedant.toString()+
                   " De taille: "+Lantecedant.size());
            for(int j=0;j<Lantecedant.size();j++)
               {  System.out.println(" je parcours la liste de mes  antécédants , je suis à l'antécédant : "+Lantecedant.get(j));
                    Tache tache =getInstances().get(getIdTacheByName(Lantecedant.get(j).trim()));
                  System.out.println("je suis la tache"+nom+" et je suis  le suivant de la tache: "+tache.nom);
                    tache.Lsuivant.add(nom);
                    }
            }
        
        else
        {       //si je suis un début , alors je n'auraii pas d'antecedant
               getAntecedant().nom="nulle";

        }
        }
   
   public void antecedantNonChoisi()
   {
       if(this!=getSuivant().getAntecedant())
       {
           System.out.println("");
           antecedantNonChoisi=true; 
       }
   }
   
   public void DatePlusTard()
   {    
       if(id==IdFIN){DPTard=DPTot;}
       else
       {
           if(antecedantNonChoisi==true)
           {
               DPTard=suivant.DPTard-suivant.durée;
               
           }
           else
           {
               
               ArrayList <Integer> valeursDptard = new ArrayList<>(); 
               for(int j=0;j<Lsuivant.size();j++)
               {
                   Tache suivant=instances.get(getIdTacheByName(Lsuivant.get(j)));
                   valeursDptard.add(suivant.DPTard -suivant.durée);
               }
               // on retient l'antécédant qui donne la date la plus tard la plus petite. 
               int min=valeursDptard.get(0);// initialisation de min
               int Idmin=0;
               for(int k=0;k<valeursDptard.size();k++)
               {
                   if(min>valeursDptard.get(k))
                   {min=valeursDptard.get(k);
                    Idmin=k;
                   }  
               }
               // on affecte le suivant choisi et  date la plus tard trouver à la tache . 
               suivant=instances.get(getIdTacheByName(Lsuivant.get(Idmin)));
               DPTard=suivant.DPTard-suivant.durée;
               
               
           }
           
           
          
       
       }
      
   }
   
   public void resetMarge(){
   marge=DPTard-DPTot;
   
   if(marge==0){ critique=true;}
   }
   
   public void updateDate(){
    DateDebutPlusTot=antecedant.DPTot;
    DateDebutPlusTard=antecedant.DPTard;
    DateFinPlusTot=DPTot;
    DateFinPlusTard=DPTard;
   
   }
   
   }

   
    
   
    

