
/*********************************** 4GI ENSPY 2025**********************************************************/
/*********************************** Nom Projet : TP RO2 Algorithme de Pert *********************************/
				
               Ce Projet Implémente l'algorithme de PERT . Avec une approche orienté objet absolue. 





/******************************** Auteur du code  : Mowoum Foupouagnigni(backend) , Mbang belvine ( interface front end)************/


/**************************Attention************************************************************************/
Nous ce programme marche sans faute . Des bugs peuvent survenir dans certains cas spécifiques car toutes les situations ( validation des entrées n'ont pas été gerer). 

on suppose que le tableau du reseau pert que vous entrer sous la forme d'une matrice est ordonné dont les champs sont : Tache ,Durée,Antecedant


/****************************Utilisation********************************************************************/

il vous suffit dès lors à lancer la classe main ( main classe) qui se trouve dans le package interfacePert pour pouvoir utiliser notre algorithme à travers son interface. 
Vous pouvez directement modifier le reseau Pert à travers l'interface. 

Dans la console , vous verrez aussi les resultats , et la trace d 'execution de certaines parties de l'algorithme. 
  